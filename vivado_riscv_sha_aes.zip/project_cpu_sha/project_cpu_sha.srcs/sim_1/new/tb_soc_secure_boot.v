`timescale 1ns/1ps

module tb_soc_secure_boot_debug;

    parameter BOOT_ROM_FILE      = "boot_rom.hex";
    parameter BOOT_ROM_WORDS     = 1024;
    parameter FIRMWARE_ROM_FILE  = "firmware_cipher.hex";
    parameter FIRMWARE_ROM_WORDS = 128;

    parameter FW_BASE_ADDR       = 32'h10000000;
    parameter SEC_BASE_ADDR      = 32'h60000000;

    parameter MAX_FW_WORDS       = 512;
    parameter MAX_AES_BLOCKS     = 256;
    parameter MAX_SHA_WORDS      = 1024;

    parameter CHECK_EXPECTED_DIGEST = 1'b0;
    parameter [511:0] EXPECTED_DIGEST =
        512'h090ba70e3e9da241359fd4a925cdf2f5896233cc27bf39b7cc08b97ff8c596136aca1ab0ded4a9022675e2977c328915588c7d3630dff4fcefb6cb045d8a5655;

    reg clk;
    reg rst;
    reg intr;

    integer i;
    integer mismatch;
    integer digest_mismatch;
    integer fw_word_count;
    integer aes_in_count;
    integer aes_out_count;
    integer sha_word_count;
    integer compare_ok;
    integer done_seen;

    reg [31:0]  fw_words        [0:MAX_FW_WORDS-1];

    reg [127:0] aes_in_blocks   [0:MAX_AES_BLOCKS-1];
    reg         aes_in_last     [0:MAX_AES_BLOCKS-1];
    reg [15:0]  aes_in_keep     [0:MAX_AES_BLOCKS-1];

    reg [127:0] aes_out_blocks  [0:MAX_AES_BLOCKS-1];
    reg         aes_out_last    [0:MAX_AES_BLOCKS-1];
    reg [15:0]  aes_out_keep    [0:MAX_AES_BLOCKS-1];
    reg [127:0] aes_ctr_seen    [0:MAX_AES_BLOCKS-1];
    reg [127:0] aes_ks_seen     [0:MAX_AES_BLOCKS-1];

    reg [31:0]  sha_words       [0:MAX_SHA_WORDS-1];
    reg         sha_last_flags  [0:MAX_SHA_WORDS-1];
    reg [1:0]   sha_byte_nums   [0:MAX_SHA_WORDS-1];

    reg [31:0]  fw_addr_pending;
    reg         fw_addr_pending_valid;

    reg [31:0]  sec_awaddr_pending;
    reg         sec_awaddr_pending_valid;

    reg [31:0]  sec_araddr_pending;
    reg         sec_araddr_pending_valid;

    reg [511:0] digest_dbg;

    soc_top #(
        .BOOT_ROM_FILE      (BOOT_ROM_FILE),
        .BOOT_ROM_WORDS     (BOOT_ROM_WORDS),
        .FIRMWARE_ROM_FILE  (FIRMWARE_ROM_FILE),
        .FIRMWARE_ROM_WORDS (FIRMWARE_ROM_WORDS)
    ) dut (
        .clk_i  (clk),
        .rst_i  (rst),
        .intr_i (intr)
    );

    // ============================================================
    // SEC engine path
    // Neu loi compile o cac wire nay:
    // 1. Kiem tra decoder moi da thay decoder cu chua.
    // 2. Kiem tra instance trong decoder co ten u_axi4_secureboot_crypto_engine chua.
    // ============================================================
    wire sec_busy =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.engine_busy_q;

    wire sec_done =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.engine_done_q;

    wire sec_error =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.engine_error_q;

    wire sec_sha_overflow =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.sha_overflow_w;

    wire [3:0] sec_state =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.engine_state_q;

    wire [31:0] sec_fw_size =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.fw_size_bytes_q;

    wire [31:0] sec_fw_offset =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.fw_word_offset_q;

    wire [31:0] sec_run_size =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.run_fw_size_bytes_q;

    wire [31:0] sec_run_off =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.run_fw_word_offset_q;

    wire [31:0] sec_offset =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.offset_q;

    wire [4:0] sec_valid_bytes =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.valid_bytes_q;

    wire sec_key_load =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_key_load_q;

    wire sec_ctr_load =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_ctr_load_q;

    wire sec_aes_in_valid =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_valid_in_q;

    wire [127:0] sec_aes_in_data =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_data_in_q;

    wire sec_aes_in_last =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_last_in_q;

    wire [15:0] sec_aes_in_keep =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_keep_in_q;

    wire sec_aes_out_valid =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_valid_out_w;

    wire [127:0] sec_aes_out_data =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_data_out_w;

    wire sec_aes_out_last =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_last_out_w;

    wire [15:0] sec_aes_out_keep =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_keep_out_w;

    wire [127:0] sec_aes_ctr_dbg =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_ctr_dbg_w;

    wire [127:0] sec_aes_ks_dbg =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.aes_keystream_dbg_w;

    wire sec_sha_init =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.sha_init_q;

    wire sec_sha_start =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.sha_start_q;

    wire sec_sha_feed =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.sha_data_valid_q;

    wire [31:0] sec_sha_data =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.sha_data_q;

    wire sec_sha_last =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.sha_is_last_q;

    wire [1:0] sec_sha_byte_num =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.sha_byte_num_q;

    wire sec_sha_done =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.sha_done_w;

    wire [511:0] sec_digest =
        dut.u_axi_d_simple_decoder_secureboot.u_axi4_secureboot_crypto_engine.sha_digest_w;

    // ============================================================
    // Clock
    // ============================================================
    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    // ============================================================
    // Helper functions
    // ============================================================
    function integer count_keep_bytes;
        input [15:0] keep_mask;
        integer k;
        begin
            count_keep_bytes = 0;
            for (k = 0; k < 16; k = k + 1) begin
                if (keep_mask[k])
                    count_keep_bytes = count_keep_bytes + 1;
            end
        end
    endfunction

    function [31:0] get_word128;
        input [127:0] block;
        input integer word_idx;
        begin
            case (word_idx)
                0: get_word128 = block[127:96];
                1: get_word128 = block[95:64];
                2: get_word128 = block[63:32];
                3: get_word128 = block[31:0];
                default: get_word128 = 32'hDEADBEEF;
            endcase
        end
    endfunction

    function [31:0] mask_by_byte_num;
        input [1:0] byte_num;
        begin
            case (byte_num)
                2'd0: mask_by_byte_num = 32'hFFFFFFFF;
                2'd1: mask_by_byte_num = 32'hFF000000;
                2'd2: mask_by_byte_num = 32'hFFFF0000;
                2'd3: mask_by_byte_num = 32'hFFFFFF00;
            endcase
        end
    endfunction

    // ============================================================
    // Init
    // ============================================================
    initial begin
        intr                  = 1'b0;
        rst                   = 1'b1;

        mismatch              = 0;
        digest_mismatch       = 0;
        fw_word_count         = 0;
        aes_in_count          = 0;
        aes_out_count         = 0;
        sha_word_count        = 0;
        compare_ok            = 0;
        done_seen             = 0;

        fw_addr_pending       = 32'd0;
        fw_addr_pending_valid = 1'b0;

        sec_awaddr_pending       = 32'd0;
        sec_awaddr_pending_valid = 1'b0;
        sec_araddr_pending       = 32'd0;
        sec_araddr_pending_valid = 1'b0;

        digest_dbg            = 512'd0;

        for (i = 0; i < MAX_FW_WORDS; i = i + 1)
            fw_words[i] = 32'd0;

        for (i = 0; i < MAX_AES_BLOCKS; i = i + 1) begin
            aes_in_blocks[i]  = 128'd0;
            aes_in_last[i]    = 1'b0;
            aes_in_keep[i]    = 16'd0;

            aes_out_blocks[i] = 128'd0;
            aes_out_last[i]   = 1'b0;
            aes_out_keep[i]   = 16'd0;
            aes_ctr_seen[i]   = 128'd0;
            aes_ks_seen[i]    = 128'd0;
        end

        for (i = 0; i < MAX_SHA_WORDS; i = i + 1) begin
            sha_words[i]      = 32'd0;
            sha_last_flags[i] = 1'b0;
            sha_byte_nums[i]  = 2'd0;
        end

        repeat (20) @(posedge clk);
        rst = 1'b0;

        $display("\n===========================================================");
        $display(" Secure Boot Debug TB - SEC ENGINE MODE");
        $display(" BootROM moi phai ghi engine tai 0x6000_0000");
        $display(" TB nay khong cho dut.sha_done cu nua");
        $display("===========================================================\n");
    end

    // ============================================================
    // Timeout
    // ============================================================
    initial begin : timeout_watchdog
        repeat (120000) @(posedge clk);

        $display("\n[TIMEOUT] Khong thay SEC_DONE trong gioi han mo phong.");
        $display("sec_busy=%0d sec_done=%0d sec_error=%0d sha_overflow=%0d state=%0d",
                 sec_busy, sec_done, sec_error, sec_sha_overflow, sec_state);
        $display("sec_fw_size=%0d sec_fw_offset=%0d run_size=%0d run_off=%0d offset=%0d",
                 sec_fw_size, sec_fw_offset, sec_run_size, sec_run_off, sec_offset);

        print_summary;
        $finish;
    end

    always @(posedge clk) begin
        if (!rst)
            digest_dbg <= sec_digest;
    end

    // ============================================================
    // Monitor CPU read firmware ROM
    // ============================================================
    always @(posedge clk) begin
        if (!rst) begin
            #1;

            if (dut.axi_d_arvalid && dut.axi_d_arready &&
                (dut.axi_d_araddr >= FW_BASE_ADDR) &&
                (dut.axi_d_araddr <  (FW_BASE_ADDR + (FIRMWARE_ROM_WORDS * 4)))) begin
                fw_addr_pending       = dut.axi_d_araddr;
                fw_addr_pending_valid = 1'b1;
            end

            if (dut.axi_d_rvalid && dut.axi_d_rready && fw_addr_pending_valid) begin
                if (fw_word_count < MAX_FW_WORDS) begin
                    fw_words[fw_word_count] = dut.axi_d_rdata;

                    $display("[%0t] CPU_FW_READ   FW[%0d] @%08x = %08x",
                             $time, fw_word_count, fw_addr_pending, dut.axi_d_rdata);

                    fw_word_count = fw_word_count + 1;
                end

                fw_addr_pending_valid = 1'b0;
            end
        end
    end

    // ============================================================
    // Monitor CPU access SEC engine register 0x6000_0000
    // ============================================================
    always @(posedge clk) begin
        if (!rst) begin
            #1;

            if (dut.axi_d_awvalid && dut.axi_d_awready &&
                (dut.axi_d_awaddr >= SEC_BASE_ADDR) &&
                (dut.axi_d_awaddr <  (SEC_BASE_ADDR + 32'h100))) begin
                sec_awaddr_pending       = dut.axi_d_awaddr;
                sec_awaddr_pending_valid = 1'b1;
            end

            if (dut.axi_d_wvalid && dut.axi_d_wready && sec_awaddr_pending_valid) begin
                $display("[%0t] SEC_WR        @%08x <= %08x",
                         $time, sec_awaddr_pending, dut.axi_d_wdata);

                sec_awaddr_pending_valid = 1'b0;
            end

            if (dut.axi_d_arvalid && dut.axi_d_arready &&
                (dut.axi_d_araddr >= SEC_BASE_ADDR) &&
                (dut.axi_d_araddr <  (SEC_BASE_ADDR + 32'h100))) begin
                sec_araddr_pending       = dut.axi_d_araddr;
                sec_araddr_pending_valid = 1'b1;
            end

            if (dut.axi_d_rvalid && dut.axi_d_rready && sec_araddr_pending_valid) begin
                $display("[%0t] SEC_RD        @%08x => %08x",
                         $time, sec_araddr_pending, dut.axi_d_rdata);

                sec_araddr_pending_valid = 1'b0;
            end
        end
    end

    // ============================================================
    // Monitor engine key / IV load
    // ============================================================
    always @(posedge clk) begin
        if (!rst) begin
            #1;

            if (sec_key_load) begin
                $display("[%0t] SEC_AES_KEY_LOAD key=%064x",
                         $time,
                         dut.u_axi_d_simple_decoder_secureboot
                            .u_axi4_secureboot_crypto_engine.run_key_q);
            end

            if (sec_ctr_load) begin
                $display("[%0t] SEC_AES_IV_LOAD  iv =%032x",
                         $time,
                         dut.u_axi_d_simple_decoder_secureboot
                            .u_axi4_secureboot_crypto_engine.run_ctr_init_q);
            end
        end
    end

    // ============================================================
    // Monitor ciphertext block into AES inside SEC engine
    // ============================================================
    always @(posedge clk) begin
        if (!rst) begin
            #1;

            if (sec_aes_in_valid) begin
                if (aes_in_count < MAX_AES_BLOCKS) begin
                    aes_in_blocks[aes_in_count] = sec_aes_in_data;
                    aes_in_last[aes_in_count]   = sec_aes_in_last;
                    aes_in_keep[aes_in_count]   = sec_aes_in_keep;

                    $display("[%0t] SEC_AES_IN   BLK[%0d] = %032x  last=%0d keep=%04x offset=%0d valid_bytes=%0d",
                             $time,
                             aes_in_count,
                             sec_aes_in_data,
                             sec_aes_in_last,
                             sec_aes_in_keep,
                             sec_offset,
                             sec_valid_bytes);

                    aes_in_count = aes_in_count + 1;
                end
            end
        end
    end

    // ============================================================
    // Monitor plaintext block out from AES inside SEC engine
    // ============================================================
    always @(posedge clk) begin
        if (!rst) begin
            #1;

            if (sec_aes_out_valid) begin
                if (aes_out_count < MAX_AES_BLOCKS) begin
                    aes_out_blocks[aes_out_count] = sec_aes_out_data;
                    aes_out_last[aes_out_count]   = sec_aes_out_last;
                    aes_out_keep[aes_out_count]   = sec_aes_out_keep;
                    aes_ctr_seen[aes_out_count]   = sec_aes_ctr_dbg;
                    aes_ks_seen[aes_out_count]    = sec_aes_ks_dbg;

                    $display("[%0t] SEC_AES_OUT  BLK[%0d] = %032x  last=%0d keep=%04x ctr=%032x",
                             $time,
                             aes_out_count,
                             sec_aes_out_data,
                             sec_aes_out_last,
                             sec_aes_out_keep,
                             sec_aes_ctr_dbg);

                    aes_out_count = aes_out_count + 1;
                end
            end
        end
    end

    // ============================================================
    // Monitor SHA input inside SEC engine
    // ============================================================
    always @(posedge clk) begin
        if (!rst) begin
            #1;

            if (sec_sha_init)
                $display("[%0t] SEC_SHA_INIT", $time);

            if (sec_sha_start)
                $display("[%0t] SEC_SHA_START", $time);

            if (sec_sha_feed) begin
                if (sha_word_count < MAX_SHA_WORDS) begin
                    sha_words[sha_word_count]      = sec_sha_data;
                    sha_last_flags[sha_word_count] = sec_sha_last;
                    sha_byte_nums[sha_word_count]  = sec_sha_byte_num;

                    $display("[%0t] SEC_SHA_FEED IN[%0d] = %08x  is_last=%0d  byte_num=%0d",
                             $time,
                             sha_word_count,
                             sec_sha_data,
                             sec_sha_last,
                             sec_sha_byte_num);

                    sha_word_count = sha_word_count + 1;
                end
            end

            if (sec_sha_done)
                $display("[%0t] SEC_SHA_DONE", $time);
        end
    end

    // ============================================================
    // Finish when SEC engine done/error
    // ============================================================
    always @(posedge clk) begin
        if (!rst) begin
            #1;

            if ((sec_done || sec_error) && !done_seen) begin
                done_seen = 1;

                if (sec_done)
                    $display("[%0t] SEC_DONE", $time);

                if (sec_error)
                    $display("[%0t] SEC_ERROR", $time);

                if (sec_sha_overflow)
                    $display("[%0t] SEC_SHA_OVERFLOW", $time);

                compare_aes_to_sha_stream;
                compare_digest_if_enabled;
                print_summary;

                disable timeout_watchdog;

                #20;
                $finish;
            end
        end
    end

    // ============================================================
    // Compare AES plaintext stream with SHA input stream
    // ============================================================
    task compare_aes_to_sha_stream;
        integer bi;
        integer wi;
        integer exp_idx;
        integer valid_bytes;
        integer full_words;
        integer rem_bytes;

        reg [31:0] exp_word;
        reg        exp_last;
        reg [1:0]  exp_byte_num;
        reg [31:0] cmp_mask;
        begin
            mismatch = 0;
            exp_idx  = 0;

            for (bi = 0; bi < aes_out_count; bi = bi + 1) begin
                valid_bytes = count_keep_bytes(aes_out_keep[bi]);

                if (!aes_out_last[bi])
                    valid_bytes = 16;
                else if (valid_bytes == 0)
                    valid_bytes = 16;

                full_words = valid_bytes / 4;
                rem_bytes  = valid_bytes % 4;

                for (wi = 0; wi < full_words; wi = wi + 1) begin
                    exp_word     = get_word128(aes_out_blocks[bi], wi);
                    exp_last     = (aes_out_last[bi] &&
                                    (rem_bytes == 0) &&
                                    (wi == (full_words - 1)));
                    exp_byte_num = 2'd0;
                    cmp_mask     = 32'hFFFFFFFF;

                    if (exp_idx >= sha_word_count) begin
                        mismatch = mismatch + 1;
                        $display("[CHECK] FAIL: thieu SHA word tai exp_idx=%0d", exp_idx);
                    end else if (((sha_words[exp_idx] & cmp_mask) !== (exp_word & cmp_mask)) ||
                                 (sha_last_flags[exp_idx] !== exp_last) ||
                                 (sha_byte_nums[exp_idx]  !== exp_byte_num)) begin
                        mismatch = mismatch + 1;
                        $display("[CHECK] FAIL @word %0d", exp_idx);
                        $display("        EXP word=%08x last=%0d byte_num=%0d",
                                 exp_word, exp_last, exp_byte_num);
                        $display("        GOT word=%08x last=%0d byte_num=%0d",
                                 sha_words[exp_idx],
                                 sha_last_flags[exp_idx],
                                 sha_byte_nums[exp_idx]);
                    end

                    exp_idx = exp_idx + 1;
                end

                if (rem_bytes != 0) begin
                    exp_word     = get_word128(aes_out_blocks[bi], full_words);
                    exp_last     = 1'b1;
                    exp_byte_num = rem_bytes[1:0];
                    cmp_mask     = mask_by_byte_num(exp_byte_num);

                    if (exp_idx >= sha_word_count) begin
                        mismatch = mismatch + 1;
                        $display("[CHECK] FAIL: thieu SHA partial word tai exp_idx=%0d", exp_idx);
                    end else if (((sha_words[exp_idx] & cmp_mask) !== (exp_word & cmp_mask)) ||
                                 (sha_last_flags[exp_idx] !== exp_last) ||
                                 (sha_byte_nums[exp_idx]  !== exp_byte_num)) begin
                        mismatch = mismatch + 1;
                        $display("[CHECK] FAIL @partial word %0d", exp_idx);
                        $display("        EXP word=%08x mask=%08x last=%0d byte_num=%0d",
                                 exp_word, cmp_mask, exp_last, exp_byte_num);
                        $display("        GOT word=%08x mask=%08x last=%0d byte_num=%0d",
                                 sha_words[exp_idx],
                                 cmp_mask,
                                 sha_last_flags[exp_idx],
                                 sha_byte_nums[exp_idx]);
                    end

                    exp_idx = exp_idx + 1;
                end
            end

            if (exp_idx != sha_word_count) begin
                mismatch = mismatch + 1;
                $display("[CHECK] FAIL: so luong SHA word khong khop. exp=%0d got=%0d",
                         exp_idx, sha_word_count);
            end

            compare_ok = (mismatch == 0);

            if (compare_ok)
                $display("\n[CHECK] PASS: Stream plaintext tu SEC AES-CTR -> SEC SHA khop.\n");
            else
                $display("\n[CHECK] FAIL: Stream plaintext tu SEC AES-CTR -> SEC SHA KHONG khop.\n");
        end
    endtask

    task compare_digest_if_enabled;
        begin
            digest_mismatch = 0;

            if (CHECK_EXPECTED_DIGEST) begin
                if (digest_dbg !== EXPECTED_DIGEST) begin
                    digest_mismatch = 1;

                    $display("[DIGEST] FAIL: SEC digest khac EXPECTED_DIGEST");
                    $display("         GOT = %0128x", digest_dbg);
                    $display("         EXP = %0128x", EXPECTED_DIGEST);
                end else begin
                    $display("[DIGEST] PASS: SEC digest khop EXPECTED_DIGEST");
                end
            end else begin
                $display("[DIGEST] INFO: Dang bo qua compare digest CHECK_EXPECTED_DIGEST=0");
                $display("              SEC digest hien tai = %0128x", digest_dbg);
            end
        end
    endtask

    task print_summary;
        integer k;
        begin
            $display("\n================ SECURE BOOT SUMMARY ================");
            $display("sec_busy         = %0d", sec_busy);
            $display("sec_done         = %0d", sec_done);
            $display("sec_error        = %0d", sec_error);
            $display("sec_sha_overflow = %0d", sec_sha_overflow);
            $display("sec_state        = %0d", sec_state);
            $display("sec_fw_size      = %0d", sec_fw_size);
            $display("sec_fw_offset    = %0d", sec_fw_offset);
            $display("sec_run_size     = %0d", sec_run_size);
            $display("sec_run_off      = %0d", sec_run_off);

            $display("fw_word_count    = %0d", fw_word_count);
            $display("aes_in_count     = %0d", aes_in_count);
            $display("aes_out_count    = %0d", aes_out_count);
            $display("sha_word_count   = %0d", sha_word_count);
            $display("stream_compare   = %0d", compare_ok);
            $display("digest_compare   = %0d",
                     (CHECK_EXPECTED_DIGEST ? !digest_mismatch : 1));

            $display("\nSEC AES input blocks:");
            for (k = 0; k < aes_in_count; k = k + 1) begin
                $display("  AES_IN [%0d] = %032x  last=%0d keep=%04x",
                         k,
                         aes_in_blocks[k],
                         aes_in_last[k],
                         aes_in_keep[k]);
            end

            $display("\nSEC AES output blocks:");
            for (k = 0; k < aes_out_count; k = k + 1) begin
                $display("  AES_OUT[%0d] = %032x  last=%0d keep=%04x",
                         k,
                         aes_out_blocks[k],
                         aes_out_last[k],
                         aes_out_keep[k]);
            end

            $display("\nSEC SHA input words:");
            for (k = 0; k < sha_word_count; k = k + 1) begin
                $display("  SHA_IN[%0d]  = %08x  is_last=%0d  byte_num=%0d",
                         k,
                         sha_words[k],
                         sha_last_flags[k],
                         sha_byte_nums[k]);
            end

            $display("\nSEC digest hien tai:");
            $display("  %0128x", digest_dbg);
            $display("=====================================================\n");
        end
    endtask


endmodule