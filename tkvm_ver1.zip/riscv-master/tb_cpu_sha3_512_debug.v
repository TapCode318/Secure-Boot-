`timescale 1ns/1ps

module tb_cpu_sha3_512_debug;

    reg clk;
    reg rst;
    reg intr;

    integer i;
    integer mismatch;

    reg [3:0]   tb_state;
    reg         init_pulse;
    reg         start_pulse;
    reg         fw_read_pulse;
    reg         sha_feed_pulse;
    reg         compare_ok;
    reg         saw_real_last;
    reg [1:0]   last_byte_num_seen;
    reg [31:0]  fw_addr_dbg;
    reg [31:0]  fw_data_dbg;
    reg [31:0]  sha_data_dbg;
    reg [31:0]  fw_read_count;
    reg [31:0]  sha_feed_count;
    reg [511:0] digest_dbg;

    // Đã mở rộng mảng lên 128 words
    reg [31:0] fw_words       [0:127];
    reg [31:0] sha_words      [0:127];
    reg        sha_last_flags [0:127];
    reg [1:0]  sha_byte_nums  [0:127];

    localparam ST_RESET     = 4'd0;
    localparam ST_BOOT      = 4'd1;
    localparam ST_SHA_INIT  = 4'd2;
    localparam ST_FW_READ   = 4'd3;
    localparam ST_SHA_FEED  = 4'd4;
    localparam ST_SHA_START = 4'd5;
    localparam ST_SHA_DONE  = 4'd6;
    localparam ST_FINISH    = 4'd7;
    localparam ST_TIMEOUT   = 4'd8;

    soc_top #(
        .BOOT_ROM_FILE("boot_rom.hex"),
        .BOOT_ROM_WORDS(1024),
        .FIRMWARE_ROM_FILE("firmware_rom.hex"),
        .FIRMWARE_ROM_WORDS(128), // Đã mở rộng sức chứa ROM lên 128
        .BOOT_BASE_ADDR(32'h0000_0000),
        .FW_BASE_ADDR(32'h1000_0000),
        .SHA_BASE_ADDR(32'h4000_0000)
    ) dut (
        .clk_i (clk),
        .rst_i (rst),
        .intr_i(intr)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        intr = 1'b0;
        rst  = 1'b1;

        tb_state           = ST_RESET;
        init_pulse         = 1'b0;
        start_pulse        = 1'b0;
        fw_read_pulse      = 1'b0;
        sha_feed_pulse     = 1'b0;
        compare_ok         = 1'b0;
        saw_real_last      = 1'b0;
        last_byte_num_seen = 2'd0;
        fw_addr_dbg        = 32'd0;
        fw_data_dbg        = 32'd0;
        sha_data_dbg       = 32'd0;
        fw_read_count      = 32'd0;
        sha_feed_count     = 32'd0;
        digest_dbg         = 512'd0;

        // Vòng lặp khởi tạo mở rộng lên 128
        for (i = 0; i < 128; i = i + 1) begin
            fw_words[i]       = 32'd0;
            sha_words[i]      = 32'd0;
            sha_last_flags[i] = 1'b0;
            sha_byte_nums[i]  = 2'd0;
        end

        repeat (20) @(posedge clk);
        rst = 1'b0;
        tb_state = ST_BOOT;

        $display("\n===========================================================");
        $display(" CPU -> Firmware ROM -> SHA3-512 debug view");
        $display("===========================================================\n");
    end

    initial begin
        repeat (30000) @(posedge clk);
        tb_state = ST_TIMEOUT;
        $display("\n[TIMEOUT] Chua thay SHA done.");
        print_summary;
        $finish;
    end

    always @(posedge clk) begin
        init_pulse     <= 1'b0;
        start_pulse    <= 1'b0;
        fw_read_pulse  <= 1'b0;
        sha_feed_pulse <= 1'b0;

        if (!rst)
            digest_dbg <= dut.sha_digest;
    end

    always @(posedge clk) begin
        if (!rst) begin
            // SHA INIT pulse từ soc_top
            if (dut.sha_init) begin
                init_pulse <= 1'b1;
                tb_state   <= ST_SHA_INIT;
                $display("[%0t] SHA_INIT", $time);
            end

            // bắt địa chỉ firmware read (nới rộng đến 0x200 = 512 bytes = 128 words)
            if (dut.axi_d_arvalid && dut.axi_d_arready &&
                dut.axi_d_araddr >= 32'h1000_0000 &&
                dut.axi_d_araddr <  32'h1000_0200) begin
                fw_addr_dbg <= dut.axi_d_araddr;
            end

            // bắt data đọc từ firmware ROM
            if (dut.axi_d_rvalid && dut.axi_d_rready &&
                fw_addr_dbg >= 32'h1000_0000 &&
                fw_addr_dbg <  32'h1000_0200) begin
                fw_read_pulse <= 1'b1;
                fw_data_dbg   <= dut.axi_d_rdata;
                tb_state      <= ST_FW_READ;

                if (fw_read_count < 128) begin // Đã sửa thành 128
                    fw_words[fw_read_count] <= dut.axi_d_rdata;
                    $display("[%0t] FW_READ   FW[%0d] @%08x = %08x",
                             $time, fw_read_count, fw_addr_dbg, dut.axi_d_rdata);
                    fw_read_count <= fw_read_count + 1;
                end
            end

            // bắt data đẩy sang SHA theo tín hiệu THẬT
            if (dut.sha_data_valid) begin
                sha_feed_pulse <= 1'b1;
                sha_data_dbg   <= dut.sha_data;
                tb_state       <= ST_SHA_FEED;

                if (sha_feed_count < 128) begin // Đã sửa thành 128
                    sha_words[sha_feed_count]      <= dut.sha_data;
                    sha_last_flags[sha_feed_count] <= dut.sha_is_last;
                    sha_byte_nums[sha_feed_count]  <= dut.sha_byte_num;

                    $display("[%0t] SHA_FEED  IN[%0d] = %08x   is_last=%0d   byte_num=%0d",
                             $time, sha_feed_count, dut.sha_data, dut.sha_is_last, dut.sha_byte_num);

                    if (dut.sha_is_last) begin
                        saw_real_last      <= 1'b1;
                        last_byte_num_seen <= dut.sha_byte_num;
                    end

                    sha_feed_count <= sha_feed_count + 1;
                end
            end

            if (dut.sha_start) begin
                start_pulse <= 1'b1;
                tb_state    <= ST_SHA_START;
                $display("[%0t] SHA_START", $time);
            end

            if (dut.sha_done) begin
                tb_state <= ST_SHA_DONE;
                compare_streams;
                print_summary;
                tb_state <= ST_FINISH;
                #20;
                $finish;
            end
        end
    end

    task compare_streams;
        integer k;
        begin
            mismatch = 0;

            // So sánh linh hoạt: Bỏ qua fw_words[0] vì nó là Dữ liệu Header
            for (k = 0; k < sha_feed_count; k = k + 1)
                if (fw_words[k + 1] !== sha_words[k])
                    mismatch = mismatch + 1;

            compare_ok = (mismatch == 0);

            if (mismatch == 0)
                $display("\n[CHECK] PASS: Du lieu tu Firmware -> SHA khop hoan toan!");
            else
                $display("\n[CHECK] FAIL: luong CPU -> SHA khong khop.");
        end
    endtask

    task print_summary;
        integer k;
        begin
            $display("\n================ CONNECT SUMMARY ================");
            $display("fw_read_count      = %0d", fw_read_count);
            $display("sha_feed_count     = %0d", sha_feed_count);
            $display("compare_ok         = %0d", compare_ok);
            $display("saw_real_last      = %0d", saw_real_last);
            $display("last_byte_num_seen = %0d", last_byte_num_seen);
            $display("tb_state           = %0d", tb_state);

            $display("\nFirmware words (Word 0 la Header):");
            for (k = 0; k < fw_read_count; k = k + 1)
                $display("  FW[%0d]      = %08x", k, fw_words[k]);

            $display("\nSHA input beats:");
            for (k = 0; k < sha_feed_count; k = k + 1)
                $display("  SHA_IN[%0d]  = %08x   is_last=%0d   byte_num=%0d",
                         k, sha_words[k], sha_last_flags[k], sha_byte_nums[k]);

            $display("\nDigest hien tai:");
            $display("  %0128x", dut.sha_digest);
            $display("=================================================\n");
        end
    endtask

endmodule