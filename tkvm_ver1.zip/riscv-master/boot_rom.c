#include <stdint.h>

// ------------------------------------------------------------
// Generic SHA3-512 boot ROM logic for your current MMIO map.
//
// IMPORTANT:
//   This C code assumes the firmware ROM format is:
//     [0] total_bytes
//     [1..] payload words
//
//   Example firmware_rom.hex:
//     0000001b   // 27 bytes
//     6e677579
//     656e206b
//     686f6120
//     6d696e68
//     206c6120
//     76697020
//     646f6700
//
// MMIO map used here matches your axi_sha3_regs:
//   0x4000_0000 : CTRL      bit0=init, bit1=start
//   0x4000_0004 : STATUS    bit0=busy, bit1=done
//   0x4000_0008 : DATA      normal word
//   0x4000_000C : LAST      last word
//   0x4000_0010 : LASTBYTES 0=4 valid bytes, 1/2/3 = partial last word
//   0x4000_0020..0x4000_005C : digest[0..15]
//
// NOTE:
//   This file contains the C-side hashing logic only.
//   To run as a real boot ROM, you still need a tiny startup that sets SP
//   and jumps to c_main() (or link with a runtime that does it).
// ------------------------------------------------------------

#define SHA_BASE_ADDR      0x40000000u
#define FW_BASE_ADDR       0x10000000u

#define SHA_CTRL_OFF       0x00u
#define SHA_STATUS_OFF     0x04u
#define SHA_DATA_OFF       0x08u
#define SHA_LAST_OFF       0x0Cu
#define SHA_LASTBYTES_OFF  0x10u
#define SHA_DIGEST0_OFF    0x20u

#define SHA_CTRL_INIT      0x1u
#define SHA_CTRL_START     0x2u
#define SHA_STATUS_BUSY    0x1u
#define SHA_STATUS_DONE    0x2u

static volatile uint32_t *const sha_ctrl      = (volatile uint32_t *)(SHA_BASE_ADDR + SHA_CTRL_OFF);
static volatile uint32_t *const sha_status    = (volatile uint32_t *)(SHA_BASE_ADDR + SHA_STATUS_OFF);
static volatile uint32_t *const sha_data      = (volatile uint32_t *)(SHA_BASE_ADDR + SHA_DATA_OFF);
static volatile uint32_t *const sha_last      = (volatile uint32_t *)(SHA_BASE_ADDR + SHA_LAST_OFF);
static volatile uint32_t *const sha_lastbytes = (volatile uint32_t *)(SHA_BASE_ADDR + SHA_LASTBYTES_OFF);
static volatile uint32_t *const sha_digest    = (volatile uint32_t *)(SHA_BASE_ADDR + SHA_DIGEST0_OFF);

static volatile const uint32_t *const fw_rom  = (volatile const uint32_t *)(FW_BASE_ADDR);

// Keep digest in a global so it is easy to inspect in simulation.
volatile uint32_t g_sha3_512_digest[16];
volatile uint32_t g_total_bytes;
volatile uint32_t g_full_words;
volatile uint32_t g_rem_bytes;

static inline void mmio_write(volatile uint32_t *addr, uint32_t value)
{
    *addr = value;
}

static inline uint32_t mmio_read(volatile uint32_t *addr)
{
    return *addr;
}

static void sha3_512_hash_payload_from_rom(void)
{
    uint32_t i;
    uint32_t total_bytes;
    uint32_t full_words;
    uint32_t rem_bytes;
    volatile const uint32_t *payload;

    // firmware_rom.hex layout:
    //   word 0 = total_bytes
    //   word 1.. = payload data
    total_bytes = fw_rom[0];
    payload     = fw_rom + 1;

    full_words = total_bytes >> 2;
    rem_bytes  = total_bytes & 3u;

    g_total_bytes = total_bytes;
    g_full_words  = full_words;
    g_rem_bytes   = rem_bytes;

    // Reset/init SHA state.
    mmio_write(sha_ctrl, SHA_CTRL_INIT);

    // Configure partial-byte info for the last data beat.
    // 0 means full 4 bytes or empty-last beat.
    mmio_write(sha_lastbytes, rem_bytes);

    if (total_bytes == 0u) {
        // Empty message
        mmio_write(sha_last, 0u);
    }
    else if (rem_bytes == 0u) {
        // Message ends exactly on a 32-bit boundary.
        // Feed all real words as normal data,
        // then send one empty last beat.
        for (i = 0u; i < full_words; i++) {
            mmio_write(sha_data, payload[i]);
        }
        mmio_write(sha_last, 0u);
    }
    else {
        // There are full_words normal beats,
        // then one partial last beat at payload[full_words].
        for (i = 0u; i < full_words; i++) {
            mmio_write(sha_data, payload[i]);
        }
        mmio_write(sha_last, payload[full_words]);
    }

    // Start hashing.
    mmio_write(sha_ctrl, SHA_CTRL_START);

    // Poll until done.
    while ((mmio_read(sha_status) & SHA_STATUS_DONE) == 0u) {
        // wait
    }

    // Read back the 512-bit digest = 16 x 32-bit words.
    for (i = 0u; i < 16u; i++) {
        g_sha3_512_digest[i] = sha_digest[i];
    }
}

void c_main(void)
{
    sha3_512_hash_payload_from_rom();

    // Stop here so waveform/debug can inspect digest.
    for (;;) {
        // hang
    }
}
