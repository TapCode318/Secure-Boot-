`timescale 1ns/1ps

module tb_soc_secure_boot_debug;

    parameter BOOT_ROM_FILE      = "boot_rom.hex";
    parameter BOOT_ROM_WORDS     = 1024;
    parameter FIRMWARE_ROM_FILE  = "firmware_cipher.hex";
    parameter FIRMWARE_ROM_WORDS = 128;

    parameter FW_BASE_ADDR       = 32'h10000000;
    parameter SHA_BASE_ADDR      = 32'h40000000;
    parameter AES_BASE_ADDR      = 32'h50000000;

    parameter MAX_FW_WORDS       = 512;
    parameter MAX_AES_BLOCKS     = 256;
    parameter MAX_SHA_WORDS      = 1024;

    // Dat = 1 neu muon so sanh digest voi golden hash da biet truoc.
    parameter CHECK_EXPECTED_DIGEST = 1'b1;
    parameter [511:0] EXPECTED_DIGEST = 
        512'h090ba70e3e9da241359fd4a925cdf2f5896233cc27bf39b7cc08b97ff8c596136aca1ab0ded4a9022675e2977c328915588c7d3630dff4fcefb6cb045d8a5655;
    reg clk;
    reg rst;
    reg intr;

    integer i;
    integer mismatch;
    integer digest_mismatch;
    integer fw_word_count;
    integer aes_in_count;
    integer aes_out_count;
    integer sha_word_count;
    integer compare_ok;
    integer done_seen;

    reg [31:0] fw_words        [0:MAX_FW_WORDS-1];
    reg [127:0] aes_in_blocks  [0:MAX_AES_BLOCKS-1];
    reg [127:0] aes_out_blocks [0:MAX_AES_BLOCKS-1];
    reg         aes_out_last   [0:MAX_AES_BLOCKS-1];
    reg [15:0]  aes_out_keep   [0:MAX_AES_BLOCKS-1];
    reg [127:0] aes_ctr_seen   [0:MAX_AES_BLOCKS-1];
    reg [127:0] aes_ks_seen    [0:MAX_AES_BLOCKS-1];

    reg [31:0]  sha_words      [0:MAX_SHA_WORDS-1];
    reg         sha_last_flags [0:MAX_SHA_WORDS-1];
    reg [1:0]   sha_byte_nums  [0:MAX_SHA_WORDS-1];

    reg [31:0]  fw_addr_pending;
    reg         fw_addr_pending_valid;

    reg [511:0] digest_dbg;

    soc_top #(
        .BOOT_ROM_FILE     (BOOT_ROM_FILE),
        .BOOT_ROM_WORDS    (BOOT_ROM_WORDS),
        .FIRMWARE_ROM_FILE (FIRMWARE_ROM_FILE),
        .FIRMWARE_ROM_WORDS(FIRMWARE_ROM_WORDS)
    ) dut (
        .clk_i (clk),
        .rst_i (rst),
        .intr_i(intr)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    function integer count_keep_bytes;
        input [15:0] keep_mask;
        integer k;
        begin
            count_keep_bytes = 0;
            for (k = 0; k < 16; k = k + 1)
                if (keep_mask[k])
                    count_keep_bytes = count_keep_bytes + 1;
        end
    endfunction

    // DA CHINH SUA: Lat nguoc thu tu doc word theo chuan Big-Endian
   function [31:0] get_word128;
        input [127:0] block;
        input integer word_idx;
        begin
            case (word_idx)
                0: get_word128 = block[31:0];
                1: get_word128 = block[63:32];
                2: get_word128 = block[95:64];
                3: get_word128 = block[127:96];
                default: get_word128 = 32'hDEADBEEF;
            endcase
        end
    endfunction

    initial begin
        intr                 = 1'b0;
        rst                  = 1'b1;
        mismatch             = 0;
        digest_mismatch      = 0;
        fw_word_count        = 0;
        aes_in_count         = 0;
        aes_out_count        = 0;
        sha_word_count       = 0;
        compare_ok           = 0;
        done_seen            = 0;
        fw_addr_pending      = 32'd0;
        fw_addr_pending_valid= 1'b0;
        digest_dbg           = 512'd0;

        for (i = 0; i < MAX_FW_WORDS; i = i + 1)
            fw_words[i] = 32'd0;

        for (i = 0; i < MAX_AES_BLOCKS; i = i + 1) begin
            aes_in_blocks[i]  = 128'd0;
            aes_out_blocks[i] = 128'd0;
            aes_out_last[i]   = 1'b0;
            aes_out_keep[i]   = 16'd0;
            aes_ctr_seen[i]   = 128'd0;
            aes_ks_seen[i]    = 128'd0;
        end

        for (i = 0; i < MAX_SHA_WORDS; i = i + 1) begin
            sha_words[i]      = 32'd0;
            sha_last_flags[i] = 1'b0;
            sha_byte_nums[i]  = 2'd0;
        end

        repeat (20) @(posedge clk);
        rst = 1'b0;

        $display("\n===========================================================");
        $display(" Secure Boot System Debug TB");
        $display(" - FW ciphertext ROM -> AES-CTR -> SHA3");
        $display(" - So sanh stream AES plaintext voi stream di vao SHA");
        $display("===========================================================\n");
    end

    initial begin : timeout_watchdog
        repeat (60000) @(posedge clk);
        $display("\n[TIMEOUT] Khong thay sha_done trong gioi han mo phong.");
        print_summary;
        $finish;
    end

    always @(posedge clk) begin
        if (!rst)
            digest_dbg <= dut.sha_digest;
    end

    // Bat dia chi doc firmware ROM
    always @(posedge clk) begin
        if (!rst) begin
            if (dut.axi_d_arvalid && dut.axi_d_arready &&
                (dut.axi_d_araddr >= FW_BASE_ADDR) &&
                (dut.axi_d_araddr <  (FW_BASE_ADDR + (FIRMWARE_ROM_WORDS * 4)))) begin
                fw_addr_pending       <= dut.axi_d_araddr;
                fw_addr_pending_valid <= 1'b1;
            end

            if (dut.axi_d_rvalid && dut.axi_d_rready && fw_addr_pending_valid) begin
                if (fw_word_count < MAX_FW_WORDS) begin
                    fw_words[fw_word_count] <= dut.axi_d_rdata;
                    $display("[%0t] FW_READ    FW[%0d] @%08x = %08x",
                             $time, fw_word_count, fw_addr_pending, dut.axi_d_rdata);
                    fw_word_count <= fw_word_count + 1;
                end
                fw_addr_pending_valid <= 1'b0;
            end
        end
    end

// Bat su kien nap Key va IV vao AES
    always @(posedge clk) begin
        if (!rst) begin
            // In Key khi có lệnh Load Key
            if (dut.aes_key_load) begin
                $display("[%0t] AES_KEY_LOAD = %064x", $time, dut.aes_key);
            end
            // In IV khi có lệnh Load IV (CTR)
            if (dut.aes_ctr_load) begin
                $display("[%0t] AES_IV_LOAD  = %032x", $time, dut.aes_ctr_init);
            end
        end
    end

    // Bat block dua vao AES-CTR
    always @(posedge clk) begin
        if (!rst) begin
            if (dut.aes_valid_in) begin
                if (aes_in_count < MAX_AES_BLOCKS) begin
                    aes_in_blocks[aes_in_count] <= dut.aes_data_in;
                    $display("[%0t] AES_IN     BLK[%0d] = %032x",
                             $time, aes_in_count, dut.aes_data_in);
                    aes_in_count <= aes_in_count + 1;
                end
            end
        end
    end

    // Bat block plaintext ra tu AES-CTR
    always @(posedge clk) begin
        if (!rst) begin
            if (dut.aes_valid_out) begin
                if (aes_out_count < MAX_AES_BLOCKS) begin
                    aes_out_blocks[aes_out_count] <= dut.aes_data_out;
                    aes_out_last[aes_out_count]   <= dut.aes_last_out;
                    aes_out_keep[aes_out_count]   <= dut.aes_keep_out;
                    aes_ctr_seen[aes_out_count]   <= dut.aes_ctr_dbg;
                    aes_ks_seen[aes_out_count]    <= dut.aes_keystream_dbg;
                    $display("[%0t] AES_OUT    BLK[%0d] = %032x  last=%0d keep=%04x ctr=%032x",
                             $time, aes_out_count, dut.aes_data_out,
                             dut.aes_last_out, dut.aes_keep_out, dut.aes_ctr_dbg);
                    aes_out_count <= aes_out_count + 1;
                end
            end
        end
    end

    // Bat stream du lieu di vao SHA
    always @(posedge clk) begin
        if (!rst) begin
            if (dut.sha_init)
                $display("[%0t] SHA_INIT", $time);

            if (dut.sha_start)
                $display("[%0t] SHA_START", $time);

            if (dut.sha_data_valid) begin
                if (sha_word_count < MAX_SHA_WORDS) begin
                    sha_words[sha_word_count]      <= dut.sha_data;
                    sha_last_flags[sha_word_count] <= dut.sha_is_last;
                    sha_byte_nums[sha_word_count]  <= dut.sha_byte_num;
                    $display("[%0t] SHA_FEED   IN[%0d] = %08x  is_last=%0d  byte_num=%0d",
                             $time, sha_word_count, dut.sha_data, dut.sha_is_last, dut.sha_byte_num);
                    sha_word_count <= sha_word_count + 1;
                end
            end
        end
    end

    always @(posedge clk) begin
        if (!rst && dut.sha_done && !done_seen) begin
            done_seen <= 1;
            $display("[%0t] SHA_DONE", $time);
            compare_aes_to_sha_stream;
            compare_digest_if_enabled;
            print_summary;
            disable timeout_watchdog;
            #20;
            $finish;
        end
    end

    task compare_aes_to_sha_stream;
        integer bi;
        integer wi;
        integer exp_idx;
        integer valid_bytes;
        integer full_words;
        integer rem_bytes;
        reg [31:0] exp_word;
        reg        exp_last;
        reg [1:0]  exp_byte_num;
        begin
            mismatch = 0;
            exp_idx  = 0;

            for (bi = 0; bi < aes_out_count; bi = bi + 1) begin
                valid_bytes = count_keep_bytes(aes_out_keep[bi]);

                if (!aes_out_last[bi])
                    valid_bytes = 16;
                else if (valid_bytes == 0)
                    valid_bytes = 16;

                full_words = valid_bytes / 4;
                rem_bytes  = valid_bytes % 4;

                for (wi = 0; wi < full_words; wi = wi + 1) begin
                    exp_word     = get_word128(aes_out_blocks[bi], wi);
                    exp_last     = (aes_out_last[bi] && (rem_bytes == 0) && (wi == (full_words - 1)));
                    exp_byte_num = 2'd0;

                    if (exp_idx >= sha_word_count) begin
                        mismatch = mismatch + 1;
                        $display("[CHECK] FAIL: thieu SHA word tai exp_idx=%0d", exp_idx);
                    end else if ((sha_words[exp_idx]      !== exp_word) ||
                                 (sha_last_flags[exp_idx] !== exp_last) ||
                                 (sha_byte_nums[exp_idx]  !== exp_byte_num)) begin
                        mismatch = mismatch + 1;
                        $display("[CHECK] FAIL @word %0d", exp_idx);
                        $display("        EXP word=%08x last=%0d byte_num=%0d", exp_word, exp_last, exp_byte_num);
                        $display("        GOT word=%08x last=%0d byte_num=%0d", sha_words[exp_idx], sha_last_flags[exp_idx], sha_byte_nums[exp_idx]);
                    end
                    exp_idx = exp_idx + 1;
                end

                if (rem_bytes != 0) begin
                    exp_word     = get_word128(aes_out_blocks[bi], full_words);
                    exp_last     = 1'b1;
                    exp_byte_num = rem_bytes[1:0];

                    if (exp_idx >= sha_word_count) begin
                        mismatch = mismatch + 1;
                        $display("[CHECK] FAIL: thieu SHA last-partial word tai exp_idx=%0d", exp_idx);
                    end else if ((sha_words[exp_idx]      !== exp_word) ||
                                 (sha_last_flags[exp_idx] !== exp_last) ||
                                 (sha_byte_nums[exp_idx]  !== exp_byte_num)) begin
                        mismatch = mismatch + 1;
                        $display("[CHECK] FAIL @word %0d", exp_idx);
                        $display("        EXP partial=%08x last=%0d byte_num=%0d", exp_word, exp_last, exp_byte_num);
                        $display("        GOT partial=%08x last=%0d byte_num=%0d", sha_words[exp_idx], sha_last_flags[exp_idx], sha_byte_nums[exp_idx]);
                    end
                    exp_idx = exp_idx + 1;
                end
            end

            if (exp_idx != sha_word_count) begin
                mismatch = mismatch + 1;
                $display("[CHECK] FAIL: so luong SHA word khong khop. exp=%0d got=%0d", exp_idx, sha_word_count);
            end

            compare_ok = (mismatch == 0);
            if (compare_ok)
                $display("\n[CHECK] PASS: Stream plaintext tu AES-CTR -> SHA khop hoan toan.\n");
            else
                $display("\n[CHECK] FAIL: Stream plaintext tu AES-CTR -> SHA KHONG khop.\n");
        end
    endtask

    task compare_digest_if_enabled;
        begin
            digest_mismatch = 0;
            if (CHECK_EXPECTED_DIGEST) begin
                if (digest_dbg !== EXPECTED_DIGEST) begin
                    digest_mismatch = 1;
                    $display("[DIGEST] FAIL: sha_digest khac EXPECTED_DIGEST");
                    $display("         GOT = %0128x", digest_dbg);
                    $display("         EXP = %0128x", EXPECTED_DIGEST);
                end else begin
                    $display("[DIGEST] PASS: sha_digest khop EXPECTED_DIGEST");
                end
            end else begin
                $display("[DIGEST] INFO: Dang bo qua compare digest (CHECK_EXPECTED_DIGEST=0)");
                $display("              Digest hien tai = %0128x", digest_dbg);
            end
        end
    endtask

    task print_summary;
        integer k;
        begin
            $display("\n================ SECURE BOOT SUMMARY ================");
            $display("fw_word_count   = %0d", fw_word_count);
            $display("aes_in_count    = %0d", aes_in_count);
            $display("aes_out_count   = %0d", aes_out_count);
            $display("sha_word_count  = %0d", sha_word_count);
            $display("stream_compare  = %0d", compare_ok);
            $display("digest_compare  = %0d", (CHECK_EXPECTED_DIGEST ? !digest_mismatch : 1));

            $display("\nAES output blocks:");
            for (k = 0; k < aes_out_count; k = k + 1)
                $display("  AES_OUT[%0d] = %032x  last=%0d keep=%04x",
                         k, aes_out_blocks[k], aes_out_last[k], aes_out_keep[k]);

            $display("\nSHA input words:");
            for (k = 0; k < sha_word_count; k = k + 1)
                $display("  SHA_IN[%0d]  = %08x  is_last=%0d  byte_num=%0d",
                         k, sha_words[k], sha_last_flags[k], sha_byte_nums[k]);

            $display("\nDigest hien tai:");
            $display("  %0128x", digest_dbg);
            $display("=====================================================\n");
        end
    endtask

endmodule